import { base44 } from './base44Client';


export const saveInstallerStep = base44.functions.saveInstallerStep;

export const renderAgreementPdf = base44.functions.renderAgreementPdf;

export const submitAgreementToComply = base44.functions.submitAgreementToComply;

