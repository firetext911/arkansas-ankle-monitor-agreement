import { base44 } from './base44Client';


export const AgreementSubmission = base44.entities.AgreementSubmission;



// auth sdk:
export const User = base44.auth;